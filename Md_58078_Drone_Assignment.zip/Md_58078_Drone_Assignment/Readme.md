#GameName: Drone_Toy

#md58078


I am Mayuri Dixit. I am from Game Changers team under that I am working as a developer. This assignment contains three files which are .html,.js and .css. In this assignment a toy drone moving on a square surface The dimensions of the surface are 10 units x 10 units. The drone is free to roam around the surface. There are many functions I have added in this assignment. To perform place,attack,move,rotate for left and right. PLACE will put the toy drone on the surface in position X,Y and facing NORTH, SOUTH, EAST or WEST. MOVE will move the toy drone one unit forward in the direction it is currently facing. REPORT will announce the X,Y and F of the drone. ATTACK will cause the drone to fire a projectile 2 units ahead of the current position and explode on the surface. If there are not 2 free spaces on the surface in the direction that the drone is facing the command will be ignored. This is all about the assignment.